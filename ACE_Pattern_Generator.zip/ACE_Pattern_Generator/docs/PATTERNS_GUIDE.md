# ACE Pattern Generator - Patterns Guide

Complete guide to using pre-built integration patterns for IBM App Connect Enterprise.

## Overview

The ACE Pattern Generator provides pre-built integration patterns that follow best practices and include standard error handling, monitoring, and logging capabilities.

## Available Patterns

### 1. MQ Input to Database Update

**Pattern ID:** `mq_to_database`

**Description:** Process messages from MQ queue and update database with full monitoring and error handling.

**Use Cases:**
- Customer order processing
- Inventory updates
- Transaction logging
- Data synchronization

**Architecture:**
```
MQ Input → Monitoring IN → Transform → Database Update → Monitoring OUT
                ↓              ↓            ↓
              Error Handler ←──┴────────────┘
```

**Generated Components:**
- `flows/[AppName]_MainFlow.msgflow` - Main message flow
- `esql/[AppName]_Transform.esql` - Data transformation logic
- `esql/[AppName]_DBUpdate.esql` - Database update logic
- `subflows/ErrorHandler.subflow` - Error handling
- `subflows/MonitoringEvent_IN.subflow` - Request logging
- `subflows/MonitoringEvent_OUT.subflow` - Response logging

**Configuration:**
```bash
./generate_pattern.sh \
  --pattern mq_to_database \
  --app-name CustomerOrderApp \
  --mq-queue CUSTOMER.ORDER.IN \
  --db-schema ORDERS \
  --db-table CUSTOMER_ORDERS \
  --db-datasource ORDERS_DB
```

**Required Setup:**
1. Create MQ queue: `CUSTOMER.ORDER.IN`
2. Create error queue: `ETS.ERROR.QUEUE`
3. Configure database datasource in ACE
4. Verify database table exists

---

### 2. MQ Input to HTTP Request

**Pattern ID:** `mq_to_http`

**Description:** Process MQ messages and call external HTTP/REST/SAP service with retry logic and monitoring.

**Use Cases:**
- SAP integration
- REST API calls
- External service integration
- Microservices communication

**Architecture:**
```
MQ Input → Monitoring IN → Transform → HTTP Request → Process Response → Monitoring OUT
                ↓              ↓            ↓               ↓
              Error Handler ←──┴────────────┴───────────────┘
```

**Generated Components:**
- `flows/[AppName]_MainFlow.msgflow` - Main message flow
- `esql/[AppName]_Transform.esql` - Transform to HTTP format
- `esql/[AppName]_ProcessResponse.esql` - Response processing
- `subflows/ErrorHandler.subflow` - Error handling
- `subflows/MonitoringEvent_IN.subflow` - Request logging
- `subflows/MonitoringEvent_OUT.subflow` - Response logging

**Configuration:**
```bash
./generate_pattern.sh \
  --pattern mq_to_http \
  --app-name SAPIntegrationApp \
  --mq-queue SAP.REQUEST.QUEUE \
  --http-url https://sap-server.com/api/orders \
  --http-method POST
```

**Required Setup:**
1. Create MQ queue: `SAP.REQUEST.QUEUE`
2. Create error queue: `ETS.ERROR.QUEUE`
3. Configure HTTP endpoint URL
4. Set up SSL/TLS certificates (if HTTPS)
5. Configure authentication (Basic Auth, OAuth, etc.)

---

### 3. REST API to Database Operations

**Pattern ID:** `rest_to_database`

**Description:** Expose REST API for database CRUD operations with full monitoring.

**Use Cases:**
- Customer API
- Product catalog API
- Order management API
- Data access layer

**Architecture:**
```
HTTP Input → Monitoring IN → Route (GET/POST/PUT/DELETE) → Database Ops → Response Builder → Monitoring OUT
                  ↓                        ↓                      ↓
              Error Handler ←──────────────┴──────────────────────┘
```

**Generated Components:**
- `flows/[AppName]_MainFlow.msgflow` - Main REST flow
- `esql/[AppName]_Operations.esql` - CRUD operations
- `esql/[AppName]_ResponseBuilder.esql` - Response formatting
- `subflows/ErrorHandler.subflow` - Error handling
- `subflows/MonitoringEvent_IN.subflow` - Request logging
- `subflows/MonitoringEvent_OUT.subflow` - Response logging

**Configuration:**
```bash
./generate_pattern.sh \
  --pattern rest_to_database \
  --app-name CustomerAPIApp \
  --rest-path /api/customers \
  --db-schema CUSTOMERS \
  --db-table CUSTOMER_DATA \
  --db-datasource CUSTOMER_DB
```

**Required Setup:**
1. Configure HTTP listener port
2. Set up database datasource
3. Configure security (if required)
4. Set up CORS (if needed)

---

### 4. File Processing to Database Insert

**Pattern ID:** `file_to_database`

**Description:** Read files from directory, parse content, and insert into database.

**Use Cases:**
- Batch file processing
- CSV import
- Data migration
- File-based integration

**Architecture:**
```
File Input → Monitoring IN → Parse File → Database Insert → Archive File → Monitoring OUT
                  ↓              ↓             ↓                ↓
              Error Handler ←────┴─────────────┴────────────────┘
```

**Generated Components:**
- `flows/[AppName]_MainFlow.msgflow` - Main file processing flow
- `esql/[AppName]_Parser.esql` - File parsing logic
- `esql/[AppName]_DBInsert.esql` - Database insert logic
- `subflows/ErrorHandler.subflow` - Error handling
- `subflows/MonitoringEvent_IN.subflow` - Request logging
- `subflows/MonitoringEvent_OUT.subflow` - Response logging

**Configuration:**
```bash
./generate_pattern.sh \
  --pattern file_to_database \
  --app-name FileImportApp \
  --input-directory /data/input \
  --file-pattern "*.csv" \
  --archive-directory /data/archive \
  --db-schema DATA \
  --db-table IMPORT_DATA
```

**Required Setup:**
1. Create input directory
2. Create archive directory
3. Set up file permissions
4. Configure database datasource

---

### 5. Database Poll to MQ Output

**Pattern ID:** `database_poll_to_mq`

**Description:** Poll database for new records and publish to MQ queue.

**Use Cases:**
- Event publishing
- Change data capture
- Outbound integration
- Database-driven workflows

**Architecture:**
```
Timer → Database Select → Monitoring IN → Transform → MQ Output → Update Status → Monitoring OUT
                              ↓              ↓           ↓              ↓
                          Error Handler ←────┴───────────┴──────────────┘
```

**Generated Components:**
- `flows/[AppName]_MainFlow.msgflow` - Main polling flow
- `esql/[AppName]_Select.esql` - Database select logic
- `esql/[AppName]_Transform.esql` - Data transformation
- `esql/[AppName]_UpdateStatus.esql` - Status update logic
- `subflows/ErrorHandler.subflow` - Error handling
- `subflows/MonitoringEvent_IN.subflow` - Request logging
- `subflows/MonitoringEvent_OUT.subflow` - Response logging

**Configuration:**
```bash
./generate_pattern.sh \
  --pattern database_poll_to_mq \
  --app-name EventPublisherApp \
  --db-schema EVENTS \
  --db-table EVENT_QUEUE \
  --poll-interval 60 \
  --mq-queue EVENT.OUT.QUEUE \
  --status-column PROCESSED
```

**Required Setup:**
1. Configure database datasource
2. Create output MQ queue
3. Set up polling interval
4. Configure status column

---

## Common Features

All patterns include these standard features:

### 1. Error Handling
- Captures all exception details
- Writes to ETS error queue
- Logs error information
- Preserves original message

### 2. Monitoring
- Logs incoming requests (IN event)
- Logs outgoing responses (OUT event)
- Captures correlation IDs
- Records processing time
- Tracks business unique IDs

### 3. Logging
- User trace logging
- Service trace support
- Structured log messages
- Correlation tracking

### 4. Best Practices
- Transaction management
- Connection pooling
- Retry logic
- Timeout handling
- Data validation

---

## Customization Guide

After generating a pattern, you can customize:

### 1. ESQL Logic
Edit files in `esql/` directory to implement business logic:
```esql
-- Example: Add custom validation
IF messageBody.amount > 10000 THEN
    THROW USER EXCEPTION MESSAGE 2001 
        VALUES('Amount exceeds limit');
END IF;
```

### 2. Flow Structure
Open `.msgflow` files in ACE Toolkit to:
- Add additional nodes
- Modify routing logic
- Configure node properties
- Add conditional processing

### 3. Subflows
Modify reusable subflows in `subflows/` directory:
- Customize error handling
- Add monitoring fields
- Implement custom logging

### 4. Properties
Update connection properties:
- Database connection strings
- HTTP endpoints
- Queue names
- Timeout values

---

## Testing Patterns

### 1. Unit Testing
Test individual ESQL modules:
```bash
# Create test message
echo '{"orderId":"12345"}' > test_message.json

# Put to input queue
cat test_message.json | /opt/mqm/samp/bin/amqsput INPUT.QUEUE QM1
```

### 2. Integration Testing
Test complete flow:
```bash
# Enable monitoring
mqsichangeflowmonitoring IB10NODE -e default -f MyApp_MainFlow -c active

# Send test message
./send_test_message.sh

# Check monitoring
mqsireportflowmonitoring IB10NODE -e default -f MyApp_MainFlow

# Verify output
/opt/mqm/samp/bin/amqsget OUTPUT.QUEUE QM1
```

### 3. Error Testing
Test error scenarios:
```bash
# Send invalid message
echo 'INVALID_JSON' | /opt/mqm/samp/bin/amqsput INPUT.QUEUE QM1

# Check error queue
/opt/mqm/samp/bin/amqsget ETS.ERROR.QUEUE QM1

# View error logs
tail -f /var/mqsi/components/IB10NODE/servers/default/stdout
```

---

## Performance Tuning

### 1. Thread Pool Configuration
```bash
mqsichangeproperties IB10NODE -e default \
  -o ExecutionGroup -n httpNodesUseEmbeddedListener -v true
```

### 2. JVM Heap Size
```bash
mqsichangeproperties IB10NODE -e default \
  -o ComIbmJVMManager -n jvmMaxHeapSize -v 512M
```

### 3. Connection Pooling
Configure in flow properties:
- Database connection pool size
- HTTP connection timeout
- MQ connection pooling

---

## Troubleshooting

### Common Issues

**Issue:** Flow not starting
```bash
# Check flow status
mqsilist IB10NODE -e default -d 2

# View logs
tail -f /var/mqsi/components/IB10NODE/servers/default/stdout
```

**Issue:** Database connection fails
```bash
# Test database connectivity
mqsireportproperties IB10NODE -e default -o DataSource -r

# Check datasource configuration
mqsireportproperties IB10NODE -e default -o DataSource -n dataSourceName -r
```

**Issue:** Messages stuck in queue
```bash
# Check queue depth
echo "DISPLAY QUEUE(INPUT.QUEUE)" | runmqsc QM1

# Browse messages
/opt/mqm/samp/bin/amqsbcg INPUT.QUEUE QM1
```

---

## Best Practices

1. **Always use Error Handler subflow** for all flows
2. **Enable monitoring** for production flows
3. **Use correlation IDs** for request tracking
4. **Implement retry logic** for external calls
5. **Log to ETS queue** for error analysis
6. **Use connection pooling** for database operations
7. **Set appropriate timeouts** for HTTP requests
8. **Validate input data** before processing
9. **Test in development** before deploying to production
10. **Document customizations** in deployment guide

---

## Additional Resources

- [Runtime Commands Reference](RUNTIME_COMMANDS.md)
- [Deployment Guide](DEPLOYMENT_GUIDE.md)
- IBM ACE Documentation: https://www.ibm.com/docs/en/app-connect/

---

**Version:** 1.0.0  
**Last Updated:** 2026-06-12