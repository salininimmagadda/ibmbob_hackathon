# ACE Pattern Generator - Deployment Guide

Complete guide for deploying generated ACE applications to integration servers.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Environment Setup](#environment-setup)
3. [Import into ACE Toolkit](#import-into-ace-toolkit)
4. [Configure Application](#configure-application)
5. [Build BAR File](#build-bar-file)
6. [Deploy to Integration Server](#deploy-to-integration-server)
7. [Verify Deployment](#verify-deployment)
8. [Testing](#testing)
9. [Monitoring](#monitoring)
10. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Software Requirements
- IBM App Connect Enterprise v11.0 or higher
- IBM MQ v9.0 or higher (for MQ patterns)
- Database (Oracle, DB2, PostgreSQL, etc.) - if using database patterns
- Python 3.7+ (for pattern generator)

### Access Requirements
- ACE Toolkit installed
- Access to integration node
- MQ Queue Manager access
- Database credentials (if applicable)
- Network access to external services (if applicable)

### Knowledge Requirements
- Basic ACE concepts
- MQ administration
- Database operations
- ESQL programming (for customization)

---

## Environment Setup

### 1. Set ACE Environment
```bash
# Source ACE profile
. /opt/IBM/ace-12/server/bin/mqsiprofile

# Verify installation
mqsiversion
```

### 2. Set MQ Environment
```bash
# Source MQ profile
. /opt/mqm/bin/setmqenv -s

# Verify MQ installation
dspmqver
```

### 3. Create Integration Node (if not exists)
```bash
# Create integration node
mqsicreatebroker IB10NODE -q QM1

# Start integration node
mqsistart IB10NODE

# Verify status
mqsilist
```

### 4. Create Integration Server (if not exists)
```bash
# Create integration server
mqsicreateexecutiongroup IB10NODE -e default

# Start integration server
mqsistartexecutiongroup IB10NODE -e default

# Verify status
mqsilist IB10NODE
```

---

## Import into ACE Toolkit

### Method 1: Import Generated Project

1. **Open ACE Toolkit**
   ```bash
   /opt/IBM/ace-12/tools/ace toolkit
   ```

2. **Import Project**
   - File → Import
   - Select "Project Interchange"
   - Browse to generated application directory
   - Select the project
   - Click "Finish"

### Method 2: Create from Generated Files

1. **Create New Application**
   - File → New → Application
   - Enter application name
   - Click "Finish"

2. **Copy Generated Files**
   ```bash
   # Copy flows
   cp output/MyApp/flows/*.msgflow workspace/MyApp/

   # Copy subflows
   cp output/MyApp/subflows/*.subflow workspace/MyApp/

   # Copy ESQL
   cp output/MyApp/esql/*.esql workspace/MyApp/
   ```

3. **Refresh Project**
   - Right-click project → Refresh

---

## Configure Application

### 1. Configure MQ Queues

Create required queues:
```bash
# Start MQ command interface
runmqsc QM1

# Create input queue
DEFINE QLOCAL(CUSTOMER.ORDER.IN) MAXDEPTH(5000)

# Create error queue
DEFINE QLOCAL(ETS.ERROR.QUEUE) MAXDEPTH(10000)

# Exit
END
```

### 2. Configure Database Connection

**Option A: Using mqsisetdbparms**
```bash
mqsisetdbparms IB10NODE -n jdbc::ORDERS_DB \
  -u dbuser \
  -p dbpassword
```

**Option B: Using mqsicreateconfigurableservice**
```bash
mqsicreateconfigurableservice IB10NODE \
  -c JDBCProviders \
  -o ORDERS_DB \
  -n connectionUrlFormat \
  -v "jdbc:oracle:thin:@//dbserver:1521/ORCL"

mqsicreateconfigurableservice IB10NODE \
  -c JDBCProviders \
  -o ORDERS_DB \
  -n jarsURL \
  -v "/opt/jdbc/ojdbc8.jar"
```

### 3. Configure HTTP Endpoints (if applicable)

Set HTTP listener properties:
```bash
mqsichangeproperties IB10NODE -e default \
  -o HTTPConnector \
  -n port \
  -v 7800

mqsichangeproperties IB10NODE -e default \
  -o HTTPSConnector \
  -n port \
  -v 7843
```

### 4. Update Flow Properties

In ACE Toolkit:
1. Open message flow
2. Select nodes requiring configuration
3. Update properties:
   - Queue names
   - Database datasource
   - HTTP URLs
   - Timeout values

---

## Build BAR File

### Method 1: Using ACE Toolkit

1. **Create BAR File**
   - File → New → BAR file
   - Enter BAR file name
   - Click "Finish"

2. **Add Applications**
   - In BAR editor, click "Applications"
   - Select your application
   - Check "Compile and in-line resources"
   - Click "Build and Save"

### Method 2: Using Command Line

```bash
# Navigate to workspace
cd /home/user/workspace

# Create BAR file
mqsipackagebar -a CustomerOrderApp.bar \
  -w /home/user/workspace \
  -p CustomerOrderApp

# Verify BAR contents
mqsireadbar -b CustomerOrderApp.bar
```

### Method 3: Using Generated Script

```bash
# Use the generated build script
cd output/CustomerOrderApp
./build.sh
```

---

## Deploy to Integration Server

### 1. Deploy BAR File

```bash
# Deploy to integration server
mqsideploy IB10NODE -e default -a CustomerOrderApp.bar

# Verify deployment
mqsilist IB10NODE -e default -d 2
```

### 2. Start Message Flow

```bash
# Start the flow
mqsistartmsgflow IB10NODE -e default -f CustomerOrderApp_MainFlow

# Verify flow is running
mqsilist IB10NODE -e default -d 2
```

### 3. Enable Monitoring

```bash
# Enable flow monitoring
mqsichangeflowmonitoring IB10NODE -e default \
  -f CustomerOrderApp_MainFlow \
  -c active

# Verify monitoring status
mqsireportflowmonitoring IB10NODE -e default \
  -f CustomerOrderApp_MainFlow
```

---

## Verify Deployment

### 1. Check Integration Node Status
```bash
mqsilist
```
Expected output:
```
BIP1286I: Integration node 'IB10NODE' with administration URI 'http://localhost:4414' is running.
```

### 2. Check Integration Server Status
```bash
mqsilist IB10NODE
```
Expected output:
```
BIP1286I: Integration node 'IB10NODE' with administration URI 'http://localhost:4414' is running.
BIP8071I: Successful command completion.
Integration server 'default' is running.
```

### 3. Check Deployed Applications
```bash
mqsilist IB10NODE -e default -d 2
```
Expected output should show your application and flows.

### 4. Check Flow Status
```bash
mqsireportflowmonitoring IB10NODE -e default -f CustomerOrderApp_MainFlow
```

---

## Testing

### 1. Prepare Test Data

Create test message:
```json
{
  "orderId": "12345",
  "customer": "John Doe",
  "amount": 100.00,
  "items": [
    {
      "productId": "PROD001",
      "quantity": 2,
      "price": 50.00
    }
  ]
}
```

### 2. Send Test Message

**For MQ Input:**
```bash
# Put message to input queue
echo '{
  "orderId": "12345",
  "customer": "John Doe",
  "amount": 100.00
}' | /opt/mqm/samp/bin/amqsput CUSTOMER.ORDER.IN QM1
```

**For HTTP Input:**
```bash
# Send HTTP request
curl -X POST http://localhost:7800/api/orders \
  -H "Content-Type: application/json" \
  -d '{
    "orderId": "12345",
    "customer": "John Doe",
    "amount": 100.00
  }'
```

### 3. Verify Processing

**Check Database:**
```sql
SELECT * FROM ORDERS.CUSTOMER_ORDERS 
WHERE ORDER_ID = '12345';
```

**Check Output Queue:**
```bash
/opt/mqm/samp/bin/amqsget OUTPUT.QUEUE QM1
```

**Check Logs:**
```bash
tail -f /var/mqsi/components/IB10NODE/servers/default/stdout
```

### 4. Test Error Scenarios

**Send Invalid Message:**
```bash
echo 'INVALID_JSON' | /opt/mqm/samp/bin/amqsput CUSTOMER.ORDER.IN QM1
```

**Check Error Queue:**
```bash
/opt/mqm/samp/bin/amqsget ETS.ERROR.QUEUE QM1
```

---

## Monitoring

### 1. Enable User Trace
```bash
mqsichangetrace IB10NODE -e default -t debug -l verbose
```

### 2. View Logs
```bash
# View stdout
tail -f /var/mqsi/components/IB10NODE/servers/default/stdout

# View stderr
tail -f /var/mqsi/components/IB10NODE/servers/default/stderr

# View user trace
mqsireadlog IB10NODE -e default -u
```

### 3. Monitor Flow Statistics
```bash
# View flow monitoring data
mqsireportflowmonitoring IB10NODE -e default -f CustomerOrderApp_MainFlow

# View resource statistics
mqsireportresourcestats IB10NODE -e default
```

### 4. Monitor Queue Depths
```bash
# Display queue status
echo "DISPLAY QUEUE(CUSTOMER.ORDER.IN)" | runmqsc QM1
```

---

## Troubleshooting

### Issue: Flow Not Starting

**Symptoms:**
- Flow shows as stopped
- No messages being processed

**Solution:**
```bash
# Check flow status
mqsilist IB10NODE -e default -d 2

# Check logs for errors
tail -f /var/mqsi/components/IB10NODE/servers/default/stdout

# Try restarting flow
mqsistopmsgflow IB10NODE -e default -f CustomerOrderApp_MainFlow
mqsistartmsgflow IB10NODE -e default -f CustomerOrderApp_MainFlow
```

### Issue: Database Connection Failure

**Symptoms:**
- Database operations fail
- Connection timeout errors

**Solution:**
```bash
# Check database credentials
mqsireportproperties IB10NODE -e default -o DataSource -r

# Test database connectivity
# Update credentials if needed
mqsisetdbparms IB10NODE -n jdbc::ORDERS_DB -u dbuser -p dbpassword

# Restart integration server
mqsistopexecutiongroup IB10NODE -e default
mqsistartexecutiongroup IB10NODE -e default
```

### Issue: Messages Stuck in Queue

**Symptoms:**
- Queue depth increasing
- Messages not being processed

**Solution:**
```bash
# Check queue depth
echo "DISPLAY QUEUE(CUSTOMER.ORDER.IN)" | runmqsc QM1

# Check if flow is running
mqsilist IB10NODE -e default -d 2

# Browse messages
/opt/mqm/samp/bin/amqsbcg CUSTOMER.ORDER.IN QM1

# Check for poison messages
# Move to backout queue if needed
```

### Issue: High Memory Usage

**Symptoms:**
- Integration server consuming high memory
- OutOfMemory errors

**Solution:**
```bash
# Check current heap size
mqsireportproperties IB10NODE -e default -o ComIbmJVMManager -r

# Increase heap size
mqsichangeproperties IB10NODE -e default \
  -o ComIbmJVMManager \
  -n jvmMaxHeapSize \
  -v 1024M

# Restart integration server
mqsistopexecutiongroup IB10NODE -e default
mqsistartexecutiongroup IB10NODE -e default
```

---

## Best Practices

1. **Always test in development** before deploying to production
2. **Use BAR file overrides** for environment-specific properties
3. **Enable monitoring** for all production flows
4. **Set up log rotation** to prevent disk space issues
5. **Document all customizations** in deployment notes
6. **Keep backup** of working BAR files
7. **Use version control** for source code
8. **Monitor queue depths** regularly
9. **Set appropriate timeouts** for external calls
10. **Implement health checks** for critical flows

---

## Deployment Checklist

- [ ] Prerequisites verified
- [ ] Integration node created and started
- [ ] Integration server created and started
- [ ] MQ queues created
- [ ] Database connection configured
- [ ] Application imported into Toolkit
- [ ] Flow properties configured
- [ ] BAR file built successfully
- [ ] BAR file deployed to integration server
- [ ] Message flow started
- [ ] Monitoring enabled
- [ ] Test message sent successfully
- [ ] Output verified
- [ ] Error handling tested
- [ ] Logs reviewed
- [ ] Documentation updated

---

## Additional Resources

- [Runtime Commands Reference](RUNTIME_COMMANDS.md)
- [Patterns Guide](PATTERNS_GUIDE.md)
- IBM ACE Documentation: https://www.ibm.com/docs/en/app-connect/
- IBM MQ Documentation: https://www.ibm.com/docs/en/ibm-mq/

---

**Version:** 1.0.0  
**Last Updated:** 2026-06-12