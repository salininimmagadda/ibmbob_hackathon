# ACE Runtime Commands Reference

Complete reference for IBM App Connect Enterprise runtime commands used with generated patterns.

## Table of Contents

1. [Integration Node Commands](#integration-node-commands)
2. [Integration Server Commands](#integration-server-commands)
3. [Message Flow Commands](#message-flow-commands)
4. [BAR File Commands](#bar-file-commands)
5. [Monitoring Commands](#monitoring-commands)
6. [Queue Manager Commands](#queue-manager-commands)
7. [Troubleshooting Commands](#troubleshooting-commands)

---

## Integration Node Commands

### List Integration Nodes
```bash
mqsilist
```
Lists all integration nodes on the system.

### Create Integration Node
```bash
mqsicreatebroker NODE_NAME -q QUEUE_MANAGER
```
Example:
```bash
mqsicreatebroker IB10NODE -q QM1
```

### Start Integration Node
```bash
mqsistart NODE_NAME
```
Example:
```bash
mqsistart IB10NODE
```

### Stop Integration Node
```bash
mqsistop NODE_NAME
```
Example:
```bash
mqsistop IB10NODE
```

### Delete Integration Node
```bash
mqsideletebroker NODE_NAME
```
Example:
```bash
mqsideletebroker IB10NODE
```

---

## Integration Server Commands

### Create Integration Server
```bash
mqsicreateexecutiongroup NODE_NAME -e SERVER_NAME
```
Example:
```bash
mqsicreateexecutiongroup IB10NODE -e default
```

### Start Integration Server
```bash
mqsistartexecutiongroup NODE_NAME -e SERVER_NAME
```
Example:
```bash
mqsistartexecutiongroup IB10NODE -e default
```

### Stop Integration Server
```bash
mqsistopexecutiongroup NODE_NAME -e SERVER_NAME
```
Example:
```bash
mqsistopexecutiongroup IB10NODE -e default
```

### Delete Integration Server
```bash
mqsideleteexecutiongroup NODE_NAME -e SERVER_NAME
```
Example:
```bash
mqsideleteexecutiongroup IB10NODE -e default
```

### List Integration Servers
```bash
mqsilist NODE_NAME
```
Example:
```bash
mqsilist IB10NODE
```

---

## Message Flow Commands

### Deploy BAR File
```bash
mqsideploy NODE_NAME -e SERVER_NAME -a BAR_FILE
```
Example:
```bash
mqsideploy IB10NODE -e default -a CustomerOrderApp.bar
```

### Start Message Flow
```bash
mqsistartmsgflow NODE_NAME -e SERVER_NAME -f FLOW_NAME
```
Example:
```bash
mqsistartmsgflow IB10NODE -e default -f CustomerOrderApp_MainFlow
```

### Stop Message Flow
```bash
mqsistopmsgflow NODE_NAME -e SERVER_NAME -f FLOW_NAME
```
Example:
```bash
mqsistopmsgflow IB10NODE -e default -f CustomerOrderApp_MainFlow
```

### List Message Flows
```bash
mqsilist NODE_NAME -e SERVER_NAME -d 2
```
Example:
```bash
mqsilist IB10NODE -e default -d 2
```

### Delete Message Flow
```bash
mqsideploy NODE_NAME -e SERVER_NAME -d APPLICATION_NAME
```
Example:
```bash
mqsideploy IB10NODE -e default -d CustomerOrderApp
```

---

## BAR File Commands

### Create BAR File
```bash
mqsipackagebar -a BAR_FILE -w WORKSPACE_PATH -p PROJECT_NAME
```
Example:
```bash
mqsipackagebar -a CustomerOrderApp.bar -w /home/user/workspace -p CustomerOrderApp
```

### Create BAR with Multiple Projects
```bash
mqsipackagebar -a BAR_FILE -w WORKSPACE_PATH -p PROJECT1 -p PROJECT2
```
Example:
```bash
mqsipackagebar -a MyIntegration.bar -w /home/user/workspace -p CustomerOrderApp -p SharedLibrary
```

### Read BAR File Contents
```bash
mqsireadbar -b BAR_FILE
```
Example:
```bash
mqsireadbar -b CustomerOrderApp.bar
```

### Apply BAR File Overrides
```bash
mqsiapplybaroverride -b BAR_FILE -p PROPERTIES_FILE -o OUTPUT_BAR
```
Example:
```bash
mqsiapplybaroverride -b CustomerOrderApp.bar -p dev.properties -o CustomerOrderApp_dev.bar
```

---

## Monitoring Commands

### Report Flow Monitoring Data
```bash
mqsireportflowmonitoring NODE_NAME -e SERVER_NAME -f FLOW_NAME
```
Example:
```bash
mqsireportflowmonitoring IB10NODE -e default -f CustomerOrderApp_MainFlow
```

### Enable Flow Monitoring
```bash
mqsichangeflowmonitoring NODE_NAME -e SERVER_NAME -f FLOW_NAME -c active
```
Example:
```bash
mqsichangeflowmonitoring IB10NODE -e default -f CustomerOrderApp_MainFlow -c active
```

### Disable Flow Monitoring
```bash
mqsichangeflowmonitoring NODE_NAME -e SERVER_NAME -f FLOW_NAME -c inactive
```
Example:
```bash
mqsichangeflowmonitoring IB10NODE -e default -f CustomerOrderApp_MainFlow -c inactive
```

### Report Resource Statistics
```bash
mqsireportresourcestats NODE_NAME -e SERVER_NAME
```
Example:
```bash
mqsireportresourcestats IB10NODE -e default
```

### View Integration Server Properties
```bash
mqsireportproperties NODE_NAME -e SERVER_NAME -o AllReportableEntityNames
```
Example:
```bash
mqsireportproperties IB10NODE -e default -o AllReportableEntityNames
```

---

## Queue Manager Commands

### Display Queue Manager Status
```bash
dspmq
```

### Start Queue Manager
```bash
strmqm QUEUE_MANAGER_NAME
```
Example:
```bash
strmqm QM1
```

### Stop Queue Manager
```bash
endmqm QUEUE_MANAGER_NAME
```
Example:
```bash
endmqm QM1
```

### Create Queue
```bash
echo "DEFINE QLOCAL(QUEUE_NAME)" | runmqsc QUEUE_MANAGER_NAME
```
Example:
```bash
echo "DEFINE QLOCAL(CUSTOMER.ORDER.IN)" | runmqsc QM1
```

### Display Queue
```bash
echo "DISPLAY QUEUE(QUEUE_NAME)" | runmqsc QUEUE_MANAGER_NAME
```
Example:
```bash
echo "DISPLAY QUEUE(CUSTOMER.ORDER.IN)" | runmqsc QM1
```

### Put Message to Queue
```bash
/opt/mqm/samp/bin/amqsput QUEUE_NAME QUEUE_MANAGER_NAME
```
Example:
```bash
/opt/mqm/samp/bin/amqsput CUSTOMER.ORDER.IN QM1
```

### Get Message from Queue
```bash
/opt/mqm/samp/bin/amqsget QUEUE_NAME QUEUE_MANAGER_NAME
```
Example:
```bash
/opt/mqm/samp/bin/amqsget CUSTOMER.ORDER.IN QM1
```

---

## Troubleshooting Commands

### View Integration Node Logs
```bash
tail -f /var/mqsi/components/NODE_NAME/stdout
tail -f /var/mqsi/components/NODE_NAME/stderr
```
Example:
```bash
tail -f /var/mqsi/components/IB10NODE/stdout
```

### View Integration Server Logs
```bash
tail -f /var/mqsi/components/NODE_NAME/servers/SERVER_NAME/stdout
tail -f /var/mqsi/components/NODE_NAME/servers/SERVER_NAME/stderr
```
Example:
```bash
tail -f /var/mqsi/components/IB10NODE/servers/default/stdout
```

### View User Trace
```bash
mqsireadlog NODE_NAME -e SERVER_NAME -u
```
Example:
```bash
mqsireadlog IB10NODE -e default -u
```

### View Service Trace
```bash
mqsireadlog NODE_NAME -e SERVER_NAME -s
```
Example:
```bash
mqsireadlog IB10NODE -e default -s
```

### Change Trace Level
```bash
mqsichangetrace NODE_NAME -e SERVER_NAME -t debug -l verbose
```
Example:
```bash
mqsichangetrace IB10NODE -e default -t debug -l verbose
```

### Reset Trace Level
```bash
mqsichangetrace NODE_NAME -e SERVER_NAME -t none
```
Example:
```bash
mqsichangetrace IB10NODE -e default -t none
```

### Report Integration Node Properties
```bash
mqsireportproperties NODE_NAME -o AllReportableEntityNames -r
```
Example:
```bash
mqsireportproperties IB10NODE -o AllReportableEntityNames -r
```

### Change Integration Server Properties
```bash
mqsichangeproperties NODE_NAME -e SERVER_NAME -o ComIbmJVMManager -n jvmMaxHeapSize -v 512M
```
Example:
```bash
mqsichangeproperties IB10NODE -e default -o ComIbmJVMManager -n jvmMaxHeapSize -v 512M
```

---

## Common Workflows

### Complete Deployment Workflow
```bash
# 1. Create BAR file
mqsipackagebar -a CustomerOrderApp.bar -w /workspace -p CustomerOrderApp

# 2. Verify BAR contents
mqsireadbar -b CustomerOrderApp.bar

# 3. Deploy to integration server
mqsideploy IB10NODE -e default -a CustomerOrderApp.bar

# 4. Start the flow
mqsistartmsgflow IB10NODE -e default -f CustomerOrderApp_MainFlow

# 5. Enable monitoring
mqsichangeflowmonitoring IB10NODE -e default -f CustomerOrderApp_MainFlow -c active

# 6. Verify deployment
mqsilist IB10NODE -e default -d 2
```

### Testing Workflow
```bash
# 1. Put test message to input queue
echo '{"orderId":"12345","customer":"John Doe"}' | /opt/mqm/samp/bin/amqsput CUSTOMER.ORDER.IN QM1

# 2. Check flow monitoring
mqsireportflowmonitoring IB10NODE -e default -f CustomerOrderApp_MainFlow

# 3. Check error queue
/opt/mqm/samp/bin/amqsget ETS.ERROR.QUEUE QM1

# 4. View logs
tail -f /var/mqsi/components/IB10NODE/servers/default/stdout
```

### Troubleshooting Workflow
```bash
# 1. Check integration node status
mqsilist

# 2. Check integration server status
mqsilist IB10NODE

# 3. Check deployed flows
mqsilist IB10NODE -e default -d 2

# 4. Enable debug trace
mqsichangetrace IB10NODE -e default -t debug -l verbose

# 5. View user trace
mqsireadlog IB10NODE -e default -u

# 6. Reset trace
mqsichangetrace IB10NODE -e default -t none
```

---

## Environment Variables

### Set ACE Environment
```bash
. /opt/IBM/ace-12/server/bin/mqsiprofile
```

### Set MQ Environment
```bash
. /opt/mqm/bin/setmqenv -s
```

---

## Best Practices

1. **Always verify BAR contents** before deployment using `mqsireadbar`
2. **Enable monitoring** for production flows
3. **Use meaningful names** for integration nodes and servers
4. **Keep logs** for troubleshooting
5. **Test in development** before deploying to production
6. **Use BAR overrides** for environment-specific properties
7. **Monitor resource usage** regularly
8. **Stop flows** before deleting applications
9. **Backup BAR files** before deployment
10. **Document changes** in deployment logs

---

## Quick Reference Card

| Task | Command |
|------|---------|
| List nodes | `mqsilist` |
| Deploy BAR | `mqsideploy NODE -e SERVER -a BAR_FILE` |
| Start flow | `mqsistartmsgflow NODE -e SERVER -f FLOW` |
| Stop flow | `mqsistopmsgflow NODE -e SERVER -f FLOW` |
| View logs | `tail -f /var/mqsi/components/NODE/servers/SERVER/stdout` |
| Monitor flow | `mqsireportflowmonitoring NODE -e SERVER -f FLOW` |
| Create BAR | `mqsipackagebar -a BAR -w WORKSPACE -p PROJECT` |
| Read BAR | `mqsireadbar -b BAR_FILE` |

---

## Additional Resources

- IBM ACE Knowledge Center: https://www.ibm.com/docs/en/app-connect/
- ACE Command Reference: https://www.ibm.com/docs/en/app-connect/12.0?topic=reference-commands
- MQ Command Reference: https://www.ibm.com/docs/en/ibm-mq/

---

**Version:** 1.0.0  
**Last Updated:** 2026-06-12