# ACE Pattern Generator - Demo Example

This document shows a complete example of generating and deploying an ACE application using the Pattern Generator.

## Demo Scenario

**Objective:** Create an integration that processes customer orders from an MQ queue and updates a database.

**Pattern:** MQ Input to Database Update

## Step 1: Generate the Application

```bash
cd ACE_Pattern_Generator/scripts

./generate_pattern.sh \
  --pattern mq_to_database \
  --app-name DemoOrderApp \
  --mq-queue DEMO.ORDER.IN \
  --db-schema ORDERS \
  --db-table ORDER_DATA \
  --db-datasource DEMO_DB
```

**Output:**
```
============================================================
Generating ACE Application: DemoOrderApp
Pattern: mq_to_database
============================================================

📁 Creating directory structure...
📋 Generating reusable subflows...
  ✓ ErrorHandler.subflow
  ✓ ErrorHandler_Compute.esql
  ✓ MonitoringEvent_IN.subflow
  ✓ MonitoringEvent_IN_Compute.esql
  ✓ MonitoringEvent_OUT.subflow
  ✓ MonitoringEvent_OUT_Compute.esql
💻 Generating ESQL modules...
  ✓ DemoOrderApp_Transform.esql
  ✓ DemoOrderApp_DBUpdate.esql
🔄 Generating message flow...
  ✓ DemoOrderApp_MainFlow.msgflow
📝 Generating project metadata...
📖 Generating deployment guide...

✅ Application generated successfully!
📂 Location: ACE_Pattern_Generator/output/DemoOrderApp
```

## Step 2: Review Generated Structure

```
DemoOrderApp/
├── .project                              # Eclipse project file
├── application.descriptor                # ACE application descriptor
├── DEPLOYMENT.md                         # Deployment guide
├── flows/
│   └── DemoOrderApp_MainFlow.msgflow    # Main message flow
├── subflows/
│   ├── ErrorHandler.subflow             # Error handling subflow
│   ├── MonitoringEvent_IN.subflow       # Request logging subflow
│   └── MonitoringEvent_OUT.subflow      # Response logging subflow
└── esql/
    ├── DemoOrderApp_Transform.esql      # Data transformation
    ├── DemoOrderApp_DBUpdate.esql       # Database update logic
    ├── ErrorHandler_Compute.esql        # Error processing
    ├── MonitoringEvent_IN_Compute.esql  # Request monitoring
    └── MonitoringEvent_OUT_Compute.esql # Response monitoring
```

## Step 3: Setup Prerequisites

### Create MQ Queues

```bash
# Start MQ command interface
runmqsc QM1

# Create input queue
DEFINE QLOCAL(DEMO.ORDER.IN) MAXDEPTH(5000)

# Create error queue
DEFINE QLOCAL(ETS.ERROR.QUEUE) MAXDEPTH(10000)

# Exit
END
```

### Configure Database

```bash
# Set database credentials
mqsisetdbparms IB10NODE -n jdbc::DEMO_DB \
  -u dbuser \
  -p dbpassword

# Configure datasource
mqsicreateconfigurableservice IB10NODE \
  -c JDBCProviders \
  -o DEMO_DB \
  -n connectionUrlFormat \
  -v "jdbc:oracle:thin:@//dbserver:1521/ORCL"
```

### Create Database Table

```sql
CREATE TABLE ORDERS.ORDER_DATA (
    ORDER_ID VARCHAR2(50) PRIMARY KEY,
    CUSTOMER_NAME VARCHAR2(100),
    ORDER_AMOUNT NUMBER(10,2),
    ORDER_DATE TIMESTAMP,
    STATUS VARCHAR2(20)
);
```

## Step 4: Import into ACE Toolkit

1. **Open ACE Toolkit**
   ```bash
   /opt/IBM/ace-12/tools/ace toolkit
   ```

2. **Import Project**
   - File → Import
   - Select "Project Interchange"
   - Browse to: `ACE_Pattern_Generator/output/DemoOrderApp`
   - Click "Finish"

3. **Verify Import**
   - Expand project in Application Development view
   - Open `DemoOrderApp_MainFlow.msgflow`
   - Review flow structure

## Step 5: Customize (Optional)

### Update Transformation Logic

Edit `esql/DemoOrderApp_Transform.esql`:

```esql
CREATE COMPUTE MODULE DemoOrderApp_Transform
    CREATE FUNCTION Main() RETURNS BOOLEAN
    BEGIN
        -- Copy input to output
        SET OutputRoot = InputRoot;
        
        -- Extract order data
        DECLARE orderData REFERENCE TO InputRoot.JSON.Data;
        
        -- Add custom validation
        IF orderData.amount > 10000 THEN
            THROW USER EXCEPTION MESSAGE 2001 
                VALUES('Order amount exceeds limit');
        END IF;
        
        -- Add timestamp
        SET orderData.processedDate = CURRENT_TIMESTAMP;
        
        RETURN TRUE;
    END;
END MODULE;
```

## Step 6: Build BAR File

```bash
# Navigate to workspace
cd /home/user/workspace

# Build BAR file
mqsipackagebar -a DemoOrderApp.bar \
  -w /home/user/workspace \
  -p DemoOrderApp

# Verify BAR contents
mqsireadbar -b DemoOrderApp.bar
```

**Expected Output:**
```
BAR file DemoOrderApp.bar
  Application 'DemoOrderApp'
    Message Flow 'DemoOrderApp_MainFlow'
    Subflow 'ErrorHandler'
    Subflow 'MonitoringEvent_IN'
    Subflow 'MonitoringEvent_OUT'
    ESQL Module 'DemoOrderApp_Transform'
    ESQL Module 'DemoOrderApp_DBUpdate'
    ...
```

## Step 7: Deploy to Integration Server

```bash
# Deploy BAR file
mqsideploy IB10NODE -e default -a DemoOrderApp.bar

# Verify deployment
mqsilist IB10NODE -e default -d 2

# Start message flow
mqsistartmsgflow IB10NODE -e default -f DemoOrderApp_MainFlow

# Enable monitoring
mqsichangeflowmonitoring IB10NODE -e default \
  -f DemoOrderApp_MainFlow \
  -c active
```

## Step 8: Test the Integration

### Test Message 1: Valid Order

```bash
# Create test message
cat > test_order.json << EOF
{
  "orderId": "ORD-12345",
  "customerName": "John Doe",
  "amount": 250.00,
  "items": [
    {
      "productId": "PROD-001",
      "quantity": 2,
      "price": 125.00
    }
  ]
}
EOF

# Send to MQ queue
cat test_order.json | /opt/mqm/samp/bin/amqsput DEMO.ORDER.IN QM1
```

### Verify Database Insert

```sql
SELECT * FROM ORDERS.ORDER_DATA 
WHERE ORDER_ID = 'ORD-12345';
```

**Expected Result:**
```
ORDER_ID    CUSTOMER_NAME  ORDER_AMOUNT  ORDER_DATE           STATUS
ORD-12345   John Doe       250.00        2026-06-12 12:30:00  PROCESSED
```

### Test Message 2: Invalid Order (Error Scenario)

```bash
# Send invalid message
echo 'INVALID_JSON_DATA' | /opt/mqm/samp/bin/amqsput DEMO.ORDER.IN QM1

# Check error queue
/opt/mqm/samp/bin/amqsget ETS.ERROR.QUEUE QM1
```

**Expected Error Message:**
```json
{
  "ErrorHeader": {
    "Timestamp": "2026-06-12T12:35:00",
    "FlowName": "DemoOrderApp_MainFlow",
    "BusinessUniqueId": "ORD-12345",
    "CorrelationId": "..."
  },
  "ErrorDetails": {
    "ErrorDetail": [
      {
        "ErrorNumber": 1,
        "ErrorType": "ParserException",
        "ErrorCode": "2230",
        "ErrorText": "Unexpected token"
      }
    ]
  },
  "ErrorSummary": {
    "TotalErrors": 1,
    "Severity": "ERROR",
    "Status": "FAILED"
  }
}
```

## Step 9: Monitor the Flow

### View Flow Statistics

```bash
# Check flow monitoring
mqsireportflowmonitoring IB10NODE -e default -f DemoOrderApp_MainFlow
```

**Output:**
```
Flow: DemoOrderApp_MainFlow
  Total Messages: 2
  Successful: 1
  Failed: 1
  Average Processing Time: 45ms
```

### View Logs

```bash
# View stdout logs
tail -f /var/mqsi/components/IB10NODE/servers/default/stdout

# View user trace
mqsireadlog IB10NODE -e default -u
```

**Sample Log Output:**
```
[MONITORING-IN] Status=IN, BusinessId=ORD-12345, CorrelationId=..., Flow=DemoOrderApp_MainFlow
[MONITORING-OUT] Status=OUT, BusinessId=ORD-12345, Duration=45ms, Success=true
```

## Step 10: Performance Tuning (Optional)

### Increase Thread Pool

```bash
mqsichangeproperties IB10NODE -e default \
  -o ExecutionGroup \
  -n additionalInstances \
  -v 3
```

### Increase JVM Heap

```bash
mqsichangeproperties IB10NODE -e default \
  -o ComIbmJVMManager \
  -n jvmMaxHeapSize \
  -v 1024M
```

### Restart Integration Server

```bash
mqsistopexecutiongroup IB10NODE -e default
mqsistartexecutiongroup IB10NODE -e default
```

## Summary

✅ **Generated:** Complete ACE application with 3 subflows and 5 ESQL modules  
✅ **Deployed:** Successfully deployed to integration server  
✅ **Tested:** Processed valid and invalid messages  
✅ **Monitored:** Enabled monitoring and reviewed logs  
✅ **Error Handling:** Verified error messages in ETS queue  

## What We Achieved

1. **Zero Code Writing** - Generated complete application from pattern
2. **Best Practices** - Included error handling, monitoring, and logging
3. **Reusable Components** - Standard subflows for all patterns
4. **Production Ready** - Complete with deployment guide and runtime commands
5. **Customizable** - Easy to modify ESQL and flow logic

## Next Steps

1. **Add More Patterns** - Generate additional integrations
2. **Customize Logic** - Implement business-specific transformations
3. **Deploy to Production** - Follow deployment checklist
4. **Monitor Performance** - Track metrics and optimize
5. **Scale Up** - Add more integration server instances

## Additional Examples

### Generate MQ to HTTP Pattern

```bash
./generate_pattern.sh \
  --pattern mq_to_http \
  --app-name SAPIntegrationApp \
  --mq-queue SAP.REQUEST.QUEUE \
  --http-url https://sap-server.com/api/orders \
  --http-method POST
```

### Generate REST API Pattern

```bash
./generate_pattern.sh \
  --pattern rest_to_database \
  --app-name CustomerAPIApp \
  --rest-path /api/customers \
  --db-schema CUSTOMERS \
  --db-table CUSTOMER_DATA
```

---

**Congratulations!** You've successfully generated, deployed, and tested an ACE application using the Pattern Generator! 🎉