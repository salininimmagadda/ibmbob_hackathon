# ACE Pattern Generator - Quick Start Guide

Get started with the ACE Pattern Generator in 5 minutes!

## What is ACE Pattern Generator?

A standalone toolkit plugin that generates IBM App Connect Enterprise applications from pre-built patterns - **no OpenAI API required**. Each generated application includes:

✅ Complete message flows  
✅ Reusable subflows (error handling, monitoring)  
✅ ESQL modules with best practices  
✅ Deployment documentation  
✅ Runtime commands  

## Quick Start

### 1. List Available Patterns

```bash
cd ACE_Pattern_Generator/scripts
./generate_pattern.sh --list
```

### 2. Generate Your First Application

**Example: MQ to Database Pattern**

```bash
./generate_pattern.sh \
  --pattern mq_to_database \
  --app-name CustomerOrderApp \
  --mq-queue CUSTOMER.ORDER.IN \
  --db-schema ORDERS \
  --db-table CUSTOMER_ORDERS \
  --db-datasource ORDERS_DB
```

**Output:**
```
✅ Application generated successfully!
📂 Location: ACE_Pattern_Generator/output/CustomerOrderApp
```

### 3. Import into ACE Toolkit

1. Open IBM App Connect Enterprise Toolkit
2. File → Import → Project Interchange
3. Browse to `output/CustomerOrderApp`
4. Click Finish

### 4. Deploy

```bash
# Build BAR file
mqsipackagebar -a CustomerOrderApp.bar -w /workspace -p CustomerOrderApp

# Deploy to integration server
mqsideploy IB10NODE -e default -a CustomerOrderApp.bar

# Start the flow
mqsistartmsgflow IB10NODE -e default -f CustomerOrderApp_MainFlow
```

### 5. Test

```bash
# Send test message
echo '{"orderId":"12345","customer":"John Doe"}' | \
  /opt/mqm/samp/bin/amqsput CUSTOMER.ORDER.IN QM1

# Check database
SELECT * FROM ORDERS.CUSTOMER_ORDERS WHERE ORDER_ID = '12345';
```

## Available Patterns

| Pattern | Use Case | Command |
|---------|----------|---------|
| **mq_to_database** | Process MQ messages → Update database | `--pattern mq_to_database` |
| **mq_to_http** | Process MQ messages → Call HTTP/SAP | `--pattern mq_to_http` |
| **rest_to_database** | Expose REST API → Database CRUD | `--pattern rest_to_database` |
| **file_to_database** | Process files → Insert to database | `--pattern file_to_database` |
| **database_poll_to_mq** | Poll database → Publish to MQ | `--pattern database_poll_to_mq` |

## More Examples

### MQ to HTTP (SAP Integration)
```bash
./generate_pattern.sh \
  --pattern mq_to_http \
  --app-name SAPIntegrationApp \
  --mq-queue SAP.REQUEST.QUEUE \
  --http-url https://sap-server.com/api/orders \
  --http-method POST
```

### REST API to Database
```bash
./generate_pattern.sh \
  --pattern rest_to_database \
  --app-name CustomerAPIApp \
  --rest-path /api/customers \
  --db-schema CUSTOMERS \
  --db-table CUSTOMER_DATA
```

## What Gets Generated?

```
CustomerOrderApp/
├── flows/
│   └── CustomerOrderApp_MainFlow.msgflow    # Main message flow
├── subflows/
│   ├── ErrorHandler.subflow                 # Error handling
│   ├── MonitoringEvent_IN.subflow          # Request logging
│   └── MonitoringEvent_OUT.subflow         # Response logging
├── esql/
│   ├── CustomerOrderApp_Transform.esql     # Data transformation
│   ├── CustomerOrderApp_DBUpdate.esql      # Database operations
│   ├── ErrorHandler_Compute.esql           # Error processing
│   ├── MonitoringEvent_IN_Compute.esql     # Monitoring logic
│   └── MonitoringEvent_OUT_Compute.esql    # Monitoring logic
└── DEPLOYMENT.md                            # Deployment guide
```

## Features Included

### ✅ Error Handling
- Captures all exception details
- Writes to ETS error queue
- Preserves original message
- Structured error logging

### ✅ Monitoring
- Request/response logging
- Correlation ID tracking
- Processing time measurement
- Business unique ID capture

### ✅ Best Practices
- Transaction management
- Connection pooling
- Retry logic
- Timeout handling
- Data validation

## Next Steps

1. **Customize ESQL** - Edit business logic in `esql/` files
2. **Configure Properties** - Update queue names, URLs, etc.
3. **Test Thoroughly** - Use provided test scenarios
4. **Deploy to Production** - Follow deployment guide

## Documentation

- 📖 [Complete README](README.md)
- 🎯 [Patterns Guide](docs/PATTERNS_GUIDE.md)
- 🚀 [Deployment Guide](docs/DEPLOYMENT_GUIDE.md)
- 💻 [Runtime Commands](docs/RUNTIME_COMMANDS.md)

## Need Help?

```bash
# Show help
./generate_pattern.sh --help

# List all patterns
./generate_pattern.sh --list
```

## Requirements

- IBM App Connect Enterprise v11.0+
- Python 3.7+
- IBM MQ (for MQ patterns)
- Database (for database patterns)

---

**Ready to generate your first ACE application? Start with the examples above!** 🚀