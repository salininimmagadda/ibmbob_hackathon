#!/bin/bash

###############################################################################
# ACE Pattern Generator - Bash Wrapper Script
# Provides easy command-line interface for generating ACE applications
###############################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
BASE_DIR="$(dirname "$SCRIPT_DIR")"

# Python script location
PYTHON_SCRIPT="$SCRIPT_DIR/pattern_generator.py"

# Function to print colored output
print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# Function to display usage
usage() {
    cat << EOF
${GREEN}ACE Pattern Generator${NC}

Usage: $0 [OPTIONS]

Options:
    --list                      List all available patterns
    --pattern PATTERN_ID        Pattern to generate (required)
    --app-name APP_NAME         Application name (required)
    --mq-queue QUEUE_NAME       MQ queue name
    --db-schema SCHEMA          Database schema
    --db-table TABLE            Database table
    --db-datasource DATASOURCE  Database datasource name
    --http-url URL              HTTP endpoint URL
    --http-method METHOD        HTTP method (default: POST)
    --error-queue QUEUE         Error queue name (default: ETS.ERROR.QUEUE)
    --config CONFIG_FILE        JSON configuration file
    -h, --help                  Show this help message

Examples:
    # List available patterns
    $0 --list

    # Generate MQ to Database pattern
    $0 --pattern mq_to_database \\
       --app-name CustomerOrderApp \\
       --mq-queue CUSTOMER.ORDER.IN \\
       --db-schema ORDERS \\
       --db-table CUSTOMER_ORDERS \\
       --db-datasource ORDERS_DB

    # Generate MQ to HTTP pattern
    $0 --pattern mq_to_http \\
       --app-name SAPIntegrationApp \\
       --mq-queue SAP.REQUEST.QUEUE \\
       --http-url https://sap-server.com/api/orders \\
       --http-method POST

    # Generate using config file
    $0 --pattern mq_to_database \\
       --app-name MyApp \\
       --config config.json

EOF
}

# Check if Python is available
check_python() {
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 is required but not installed."
        echo "Please install Python 3.7 or higher."
        exit 1
    fi
    
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
    print_info "Using Python $PYTHON_VERSION"
}

# Check if pattern generator script exists
check_script() {
    if [ ! -f "$PYTHON_SCRIPT" ]; then
        print_error "Pattern generator script not found: $PYTHON_SCRIPT"
        exit 1
    fi
}

# Main execution
main() {
    # Check prerequisites
    check_python
    check_script
    
    # If no arguments, show usage
    if [ $# -eq 0 ]; then
        usage
        exit 0
    fi
    
    # Show header
    echo ""
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║         ACE Pattern Generator - Standalone Plugin         ║"
    echo "║              IBM App Connect Enterprise                   ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo ""
    
    # Execute Python script with all arguments
    python3 "$PYTHON_SCRIPT" "$@"
    
    EXIT_CODE=$?
    
    if [ $EXIT_CODE -eq 0 ]; then
        echo ""
        print_success "Pattern generation completed successfully!"
        echo ""
    else
        echo ""
        print_error "Pattern generation failed with exit code $EXIT_CODE"
        echo ""
        exit $EXIT_CODE
    fi
}

# Handle help flag
if [[ "$1" == "-h" ]] || [[ "$1" == "--help" ]]; then
    usage
    exit 0
fi

# Run main function
main "$@"

# Made with Bob
