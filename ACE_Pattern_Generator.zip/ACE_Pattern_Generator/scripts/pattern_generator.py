#!/usr/bin/env python3
"""
ACE Pattern Generator
Generates IBM App Connect Enterprise applications from predefined patterns
"""

import json
import os
import sys
import argparse
import shutil
from pathlib import Path
from datetime import datetime


class ACEPatternGenerator:
    def __init__(self, base_dir):
        self.base_dir = Path(base_dir)
        self.patterns_dir = self.base_dir / "patterns"
        self.templates_dir = self.base_dir / "templates"
        self.output_dir = self.base_dir / "output"
        
    def load_pattern(self, pattern_id):
        """Load pattern definition from JSON file"""
        pattern_file = self.patterns_dir / f"{pattern_id}.json"
        if not pattern_file.exists():
            raise FileNotFoundError(f"Pattern not found: {pattern_id}")
        
        with open(pattern_file, 'r') as f:
            return json.load(f)
    
    def load_catalog(self):
        """Load pattern catalog"""
        catalog_file = self.patterns_dir / "pattern_catalog.json"
        with open(catalog_file, 'r') as f:
            return json.load(f)
    
    def replace_variables(self, content, variables):
        """Replace template variables in content"""
        for key, value in variables.items():
            placeholder = f"{{{{{key}}}}}"
            content = content.replace(placeholder, str(value))
        return content
    
    def generate_application(self, pattern_id, app_name, config):
        """Generate ACE application from pattern"""
        print(f"\n{'='*60}")
        print(f"Generating ACE Application: {app_name}")
        print(f"Pattern: {pattern_id}")
        print(f"{'='*60}\n")
        
        # Load pattern definition
        pattern = self.load_pattern(pattern_id)
        
        # Prepare variables
        variables = {
            'APP_NAME': app_name,
            'ERROR_QUEUE': config.get('error_queue', 'ETS.ERROR.QUEUE'),
            **config
        }
        
        # Create output directory
        app_dir = self.output_dir / app_name
        if app_dir.exists():
            print(f"⚠️  Application directory already exists: {app_dir}")
            response = input("Overwrite? (y/n): ")
            if response.lower() != 'y':
                print("Aborted.")
                return
            shutil.rmtree(app_dir)
        
        # Create directory structure
        print("📁 Creating directory structure...")
        (app_dir / "flows").mkdir(parents=True, exist_ok=True)
        (app_dir / "subflows").mkdir(parents=True, exist_ok=True)
        (app_dir / "esql").mkdir(parents=True, exist_ok=True)
        
        # Copy and customize subflows
        print("📋 Generating reusable subflows...")
        for subflow_name in pattern.get('required_subflows', []):
            self._copy_subflow(subflow_name, app_dir, variables)
        
        # Generate ESQL modules
        print("💻 Generating ESQL modules...")
        for esql_module in pattern.get('esql_modules', []):
            self._generate_esql(esql_module, app_dir, variables)
        
        # Generate main flow
        print("🔄 Generating message flow...")
        self._generate_flow(pattern, app_dir, variables)
        
        # Generate project metadata
        print("📝 Generating project metadata...")
        self._generate_project_files(app_name, app_dir, pattern)
        
        # Generate deployment guide
        print("📖 Generating deployment guide...")
        self._generate_deployment_guide(pattern, app_dir, variables)
        
        print(f"\n✅ Application generated successfully!")
        print(f"📂 Location: {app_dir}")
        print(f"\n{'='*60}")
        print("Next Steps:")
        print("1. Import into ACE Toolkit: File → Import → Project Interchange")
        print(f"2. Review deployment guide: {app_dir}/DEPLOYMENT.md")
        print(f"3. Configure properties in message flow")
        print(f"4. Build BAR file and deploy")
        print(f"{'='*60}\n")
        
        return app_dir
    
    def _copy_subflow(self, subflow_name, app_dir, variables):
        """Copy and customize subflow template"""
        source = self.templates_dir / "subflows" / f"{subflow_name}.subflow"
        dest = app_dir / "subflows" / f"{subflow_name}.subflow"
        
        if not source.exists():
            print(f"⚠️  Subflow template not found: {subflow_name}")
            return
        
        with open(source, 'r') as f:
            content = f.read()
        
        content = self.replace_variables(content, variables)
        
        with open(dest, 'w') as f:
            f.write(content)
        
        print(f"  ✓ {subflow_name}.subflow")
        
        # Copy corresponding ESQL
        esql_source = self.templates_dir / "esql" / f"{subflow_name}_Compute.esql"
        if esql_source.exists():
            esql_dest = app_dir / "esql" / f"{subflow_name}_Compute.esql"
            with open(esql_source, 'r') as f:
                esql_content = f.read()
            esql_content = self.replace_variables(esql_content, variables)
            with open(esql_dest, 'w') as f:
                f.write(esql_content)
            print(f"  ✓ {subflow_name}_Compute.esql")
    
    def _generate_esql(self, esql_module, app_dir, variables):
        """Generate ESQL module from template"""
        module_name = self.replace_variables(esql_module['name'], variables)
        template_name = esql_module.get('template', f"{module_name}.esql")
        
        # Create ESQL content
        esql_content = f"""BROKER SCHEMA flows

/**
 * {esql_module['description']}
 * Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
 */

CREATE COMPUTE MODULE {module_name}
	CREATE FUNCTION Main() RETURNS BOOLEAN
	BEGIN
		-- Copy input to output
		SET OutputRoot = InputRoot;
		
		-- TODO: Implement business logic here
		-- This is a template - customize based on your requirements
		
		RETURN TRUE;
	END;
END MODULE;
"""
        
        dest = app_dir / "esql" / f"{module_name}.esql"
        with open(dest, 'w') as f:
            f.write(esql_content)
        
        print(f"  ✓ {module_name}.esql")
    
    def _generate_flow(self, pattern, app_dir, variables):
        """Generate message flow XML"""
        flow_name = self.replace_variables(pattern['flow_structure']['flow_name'], variables)
        
        # Generate basic flow XML structure
        flow_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<ecore:EPackage xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" 
    xmlns:ecore="http://www.eclipse.org/emf/2002/Ecore" 
    xmlns:eflow="http://www.ibm.com/wbi/2005/eflow" 
    xmlns:utility="http://www.ibm.com/wbi/2005/eflow_utility" 
    nsURI="flows/{flow_name}.msgflow" 
    nsPrefix="flows_{flow_name}.msgflow">
  <eClassifiers xmi:type="eflow:FCMComposite" name="FCMComposite_1" nodeLayoutStyle="RECTANGLE">
    <eSuperTypes href="http://www.ibm.com/wbi/2005/eflow#//FCMBlock"/>
    <translation xmi:type="utility:TranslatableString" key="{flow_name}" 
        bundleName="flows/{flow_name}" pluginId="{variables['APP_NAME']}"/>
    <composition>
      <!-- Nodes will be added here based on pattern -->
      <!-- This is a simplified template - customize in ACE Toolkit -->
    </composition>
    <propertyOrganizer/>
    <stickyBoard/>
  </eClassifiers>
</ecore:EPackage>
"""
        
        dest = app_dir / "flows" / f"{flow_name}.msgflow"
        with open(dest, 'w') as f:
            f.write(flow_xml)
        
        print(f"  ✓ {flow_name}.msgflow")
    
    def _generate_project_files(self, app_name, app_dir, pattern):
        """Generate project metadata files"""
        # .project file
        project_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<projectDescription>
	<name>{app_name}</name>
	<comment></comment>
	<projects></projects>
	<buildSpec>
		<buildCommand>
			<name>com.ibm.etools.mft.applib.applibbuilder</name>
			<arguments></arguments>
		</buildCommand>
		<buildCommand>
			<name>com.ibm.etools.mft.applib.applibresourcevalidator</name>
			<arguments></arguments>
		</buildCommand>
		<buildCommand>
			<name>com.ibm.etools.mft.connector.policy.ui.PolicyBuilder</name>
			<arguments></arguments>
		</buildCommand>
		<buildCommand>
			<name>com.ibm.etools.mft.applib.mbprojectbuilder</name>
			<arguments></arguments>
		</buildCommand>
		<buildCommand>
			<name>com.ibm.etools.msg.validation.dfdl.mlibdfdlbuilder</name>
			<arguments></arguments>
		</buildCommand>
		<buildCommand>
			<name>com.ibm.etools.mft.decision.service.ui.decisionservicerulebuilder</name>
			<arguments></arguments>
		</buildCommand>
		<buildCommand>
			<name>com.ibm.etools.mft.pattern.capture.PatternBuilder</name>
			<arguments></arguments>
		</buildCommand>
	</buildSpec>
	<natures>
		<nature>com.ibm.etools.msgbroker.tooling.applicationNature</nature>
		<nature>com.ibm.etools.msgbroker.tooling.messageBrokerProjectNature</nature>
	</natures>
</projectDescription>
"""
        
        with open(app_dir / ".project", 'w') as f:
            f.write(project_xml)
        
        # application.descriptor
        descriptor_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ns2:appDescriptor xmlns:ns2="http://com.ibm.etools.mft.descriptor.base">
    <references/>
</ns2:appDescriptor>
"""
        
        with open(app_dir / "application.descriptor", 'w') as f:
            f.write(descriptor_xml)
    
    def _generate_deployment_guide(self, pattern, app_dir, variables):
        """Generate deployment guide"""
        guide_content = f"""# Deployment Guide - {variables['APP_NAME']}

## Pattern: {pattern['pattern_name']}

**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Prerequisites

- IBM App Connect Enterprise v11.0 or higher
- MQ Queue Manager configured
- Database connection (if applicable)

## Configuration

### Required Variables
"""
        
        for var in pattern.get('configuration', {}).get('variables', []):
            guide_content += f"\n- **{var['name']}**: {var['description']}"
            if 'example' in var:
                guide_content += f" (Example: `{var['example']}`)"
        
        guide_content += "\n\n## Deployment Steps\n\n"
        
        for i, step in enumerate(pattern.get('deployment_steps', []), 1):
            step_text = self.replace_variables(step, variables)
            guide_content += f"{i}. {step_text}\n"
        
        guide_content += "\n## Testing\n\n"
        
        for i, step in enumerate(pattern.get('testing_steps', []), 1):
            step_text = self.replace_variables(step, variables)
            guide_content += f"{i}. {step_text}\n"
        
        guide_content += f"""

## Runtime Commands

### Build BAR File
```bash
mqsipackagebar -a {variables['APP_NAME']}.bar -w /path/to/workspace -p {variables['APP_NAME']}
```

### Deploy to Integration Server
```bash
mqsideploy -i localhost -e default -a {variables['APP_NAME']}.bar
```

### Start Message Flow
```bash
mqsistartmsgflow -i localhost -e default -f {variables['APP_NAME']}_MainFlow
```

### Stop Message Flow
```bash
mqsistopmsgflow -i localhost -e default -f {variables['APP_NAME']}_MainFlow
```

### Monitor Flow
```bash
mqsireportflowmonitoring -i localhost -e default -f {variables['APP_NAME']}_MainFlow
```

## Support

For issues, refer to the main ACE Pattern Generator documentation.
"""
        
        with open(app_dir / "DEPLOYMENT.md", 'w') as f:
            f.write(guide_content)
    
    def list_patterns(self):
        """List all available patterns"""
        catalog = self.load_catalog()
        
        print("\n" + "="*60)
        print("Available ACE Patterns")
        print("="*60 + "\n")
        
        for pattern in catalog['patterns']:
            print(f"ID: {pattern['id']}")
            print(f"Name: {pattern['name']}")
            print(f"Description: {pattern['description']}")
            print(f"Category: {pattern['category']}")
            print(f"Complexity: {pattern['complexity']}")
            print(f"Use Cases: {', '.join(pattern['use_cases'])}")
            print("-" * 60)
        
        print()


def main():
    parser = argparse.ArgumentParser(
        description='ACE Pattern Generator - Generate IBM App Connect Enterprise applications'
    )
    
    parser.add_argument('--list', action='store_true',
                       help='List all available patterns')
    parser.add_argument('--pattern', type=str,
                       help='Pattern ID to generate')
    parser.add_argument('--app-name', type=str,
                       help='Application name')
    parser.add_argument('--config', type=str,
                       help='Configuration JSON file')
    parser.add_argument('--mq-queue', type=str,
                       help='MQ queue name')
    parser.add_argument('--db-schema', type=str,
                       help='Database schema')
    parser.add_argument('--db-table', type=str,
                       help='Database table')
    parser.add_argument('--db-datasource', type=str,
                       help='Database datasource name')
    parser.add_argument('--http-url', type=str,
                       help='HTTP endpoint URL')
    parser.add_argument('--http-method', type=str, default='POST',
                       help='HTTP method (default: POST)')
    parser.add_argument('--error-queue', type=str, default='ETS.ERROR.QUEUE',
                       help='Error queue name (default: ETS.ERROR.QUEUE)')
    
    args = parser.parse_args()
    
    # Get base directory (parent of scripts directory)
    script_dir = Path(__file__).parent
    base_dir = script_dir.parent
    
    generator = ACEPatternGenerator(base_dir)
    
    if args.list:
        generator.list_patterns()
        return
    
    if not args.pattern or not args.app_name:
        parser.print_help()
        print("\nError: --pattern and --app-name are required")
        sys.exit(1)
    
    # Build configuration
    config = {}
    
    if args.config:
        with open(args.config, 'r') as f:
            config = json.load(f)
    else:
        # Build config from command line args
        if args.mq_queue:
            config['MQ_QUEUE'] = args.mq_queue
        if args.db_schema:
            config['DB_SCHEMA'] = args.db_schema
        if args.db_table:
            config['DB_TABLE'] = args.db_table
        if args.db_datasource:
            config['DB_DATASOURCE'] = args.db_datasource
        if args.http_url:
            config['HTTP_URL'] = args.http_url
        if args.http_method:
            config['HTTP_METHOD'] = args.http_method
        if args.error_queue:
            config['error_queue'] = args.error_queue
    
    try:
        generator.generate_application(args.pattern, args.app_name, config)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()

# Made with Bob
