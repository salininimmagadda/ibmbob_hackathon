#!/bin/bash

###############################################################################
# Push ACE Pattern Generator to GitHub
# Repository: https://github.com/salininimmagadda/ibmbob_hackathon
# Branch: Ace_Generator
###############################################################################

set -e

echo "=================================================="
echo "Pushing ACE Pattern Generator to GitHub"
echo "=================================================="
echo ""

# Navigate to the directory
cd "$(dirname "$0")"

# Configure remote
echo "📡 Configuring remote repository..."
git remote remove origin 2>/dev/null || true
git remote add origin https://github.com/salininimmagadda/ibmbob_hackathon.git

# Rename branch to Ace_Generator
echo "🔀 Renaming branch to Ace_Generator..."
git branch -M Ace_Generator

# Show current status
echo ""
echo "📊 Current status:"
git status
echo ""

# Push to GitHub
echo "🚀 Pushing to GitHub..."
echo "You will be prompted for your GitHub credentials..."
echo ""

git push -u origin Ace_Generator

echo ""
echo "=================================================="
echo "✅ Successfully pushed to GitHub!"
echo "=================================================="
echo ""
echo "View your code at:"
echo "https://github.com/salininimmagadda/ibmbob_hackathon/tree/Ace_Generator"
echo ""

# Made with Bob
