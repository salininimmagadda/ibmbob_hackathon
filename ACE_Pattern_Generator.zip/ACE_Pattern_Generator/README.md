# ACE Pattern Generator - Standalone Toolkit Plugin

## Overview

A standalone pattern generator for IBM App Connect Enterprise (ACE) that creates integration applications with pre-built patterns, reusable subflows, and standard error handling - **without requiring OpenAI API**.

## Features

- **Pre-built Integration Patterns**:
  - MQ Input → Database Update
  - MQ Input → SAP/HTTP Request
  - REST API → Database Operations
  - File Processing → Database Insert
  - Database Poll → MQ Output

- **Reusable Subflows**:
  - Error Handler (with ETS queue integration)
  - Monitoring Event IN (request logging)
  - Monitoring Event OUT (response logging)
  - Database Connection Handler
  - Retry Logic Handler

- **Standard ESQL Modules**:
  - Error handling and logging
  - Monitoring event creation
  - Data transformation utilities
  - Database operations

## Directory Structure

```
ACE_Pattern_Generator/
├── README.md                          # This file
├── patterns/                          # Pattern definitions
│   ├── pattern_catalog.json          # Available patterns
│   ├── mq_to_database.json           # MQ → DB pattern
│   ├── mq_to_http.json               # MQ → HTTP pattern
│   ├── rest_to_database.json         # REST → DB pattern
│   └── file_to_database.json         # File → DB pattern
├── templates/                         # Reusable templates
│   ├── subflows/                     # Subflow templates
│   │   ├── ErrorHandler.subflow
│   │   ├── MonitoringEvent_IN.subflow
│   │   ├── MonitoringEvent_OUT.subflow
│   │   └── DatabaseHandler.subflow
│   └── esql/                         # ESQL templates
│       ├── ErrorHandler_Compute.esql
│       ├── MonitoringEvent_IN_Compute.esql
│       ├── MonitoringEvent_OUT_Compute.esql
│       └── DatabaseOperations.esql
├── scripts/                          # Generation scripts
│   ├── generate_pattern.sh           # Main generator script
│   └── pattern_generator.py          # Python generator
└── docs/                             # Documentation
    ├── PATTERNS_GUIDE.md             # Pattern usage guide
    ├── DEPLOYMENT_GUIDE.md           # Deployment instructions
    └── RUNTIME_COMMANDS.md           # Runtime commands
```

## Quick Start

### 1. Generate a Pattern

```bash
cd ACE_Pattern_Generator/scripts

# Generate MQ to Database pattern
./generate_pattern.sh --pattern mq_to_database --app-name CustomerOrderApp

# Generate MQ to HTTP pattern
./generate_pattern.sh --pattern mq_to_http --app-name SAPIntegrationApp

# Generate REST to Database pattern
./generate_pattern.sh --pattern rest_to_database --app-name CustomerAPIApp
```

### 2. Import into ACE Toolkit

1. Open IBM App Connect Enterprise Toolkit
2. File → Import → Project Interchange
3. Select the generated `.zip` file from `output/` directory
4. Click Finish

### 3. Configure and Deploy

See [`docs/DEPLOYMENT_GUIDE.md`](docs/DEPLOYMENT_GUIDE.md) for detailed deployment steps.

## Available Patterns

### 1. MQ Input → Database Update
**Use Case**: Process messages from MQ queue and update database

**Components**:
- MQ Input node (reads from queue)
- Monitoring IN subflow (logs request)
- Compute node (transforms data)
- Database Update node
- Monitoring OUT subflow (logs response)
- Error Handler subflow (handles failures)

**Generated Files**:
- `flows/MQtoDatabase_MainFlow.msgflow`
- `esql/MQtoDatabase_Transform.esql`
- `esql/MQtoDatabase_DBUpdate.esql`

### 2. MQ Input → HTTP Request (SAP/REST)
**Use Case**: Process MQ messages and call external HTTP/SAP service

**Components**:
- MQ Input node
- Monitoring IN subflow
- Compute node (transforms to HTTP format)
- HTTP Request node
- Response processing
- Monitoring OUT subflow
- Error Handler subflow

**Generated Files**:
- `flows/MQtoHTTP_MainFlow.msgflow`
- `esql/MQtoHTTP_Transform.esql`
- `esql/MQtoHTTP_ProcessResponse.esql`

### 3. REST API → Database Operations
**Use Case**: Expose REST API for database CRUD operations

**Components**:
- HTTP Input node (REST endpoint)
- Monitoring IN subflow
- Route node (based on HTTP method)
- Database operations (INSERT/UPDATE/DELETE/SELECT)
- Response builder
- Monitoring OUT subflow
- Error Handler subflow

**Generated Files**:
- `flows/RESTtoDatabase_MainFlow.msgflow`
- `esql/RESTtoDatabase_Operations.esql`
- `esql/RESTtoDatabase_ResponseBuilder.esql`

### 4. File Processing → Database Insert
**Use Case**: Read files and insert data into database

**Components**:
- File Input node
- Monitoring IN subflow
- Compute node (parse and transform)
- Database Insert node
- File Archive/Delete
- Monitoring OUT subflow
- Error Handler subflow

**Generated Files**:
- `flows/FileToDatabase_MainFlow.msgflow`
- `esql/FileToDatabase_Parser.esql`
- `esql/FileToDatabase_DBInsert.esql`

## Pattern Configuration

Each pattern can be customized with:

```json
{
  "pattern_name": "mq_to_database",
  "app_name": "CustomerOrderApp",
  "config": {
    "mq_queue": "CUSTOMER.ORDER.IN",
    "db_schema": "ORDERS",
    "db_table": "CUSTOMER_ORDERS",
    "error_queue": "ETS.ERROR.QUEUE",
    "monitoring_enabled": true
  }
}
```

## Reusable Subflows

All patterns include these standard subflows:

### ErrorHandler.subflow
- Captures exception details
- Writes to ETS error queue
- Logs error information
- Preserves original message

### MonitoringEvent_IN.subflow
- Logs incoming request
- Captures correlation ID
- Records timestamp
- Stores business unique ID

### MonitoringEvent_OUT.subflow
- Logs outgoing response
- Records processing time
- Captures status code
- Links to request via correlation ID

### DatabaseHandler.subflow
- Connection pooling
- Transaction management
- Retry logic
- Error handling

## Runtime Commands

### Build BAR File
```bash
mqsipackagebar -a MyApp.bar -w /path/to/workspace -p CustomerOrderApp
```

### Deploy to Integration Server
```bash
mqsideploy -i localhost -e default -a MyApp.bar
```

### Start/Stop Flow
```bash
mqsistartmsgflow -i localhost -e default -f MQtoDatabase_MainFlow
mqsistopmsgflow -i localhost -e default -f MQtoDatabase_MainFlow
```

### Monitor Flow
```bash
mqsireportflowmonitoring -i localhost -e default -f MQtoDatabase_MainFlow
```

See [`docs/RUNTIME_COMMANDS.md`](docs/RUNTIME_COMMANDS.md) for complete command reference.

## Requirements

- IBM App Connect Enterprise Toolkit v11.0 or higher
- Python 3.7+ (for pattern generator script)
- Bash shell (Linux/Mac) or Git Bash (Windows)

## Installation

### Option 1: Clone Repository
```bash
git clone <repository-url>
cd ACE_Pattern_Generator
```

### Option 2: Download ZIP
1. Download the ZIP file
2. Extract to your workspace
3. Navigate to `ACE_Pattern_Generator/scripts`

## Usage Examples

### Example 1: Create Customer Order Processing App
```bash
./generate_pattern.sh \
  --pattern mq_to_database \
  --app-name CustomerOrderApp \
  --mq-queue CUSTOMER.ORDER.IN \
  --db-schema ORDERS \
  --db-table CUSTOMER_ORDERS
```

### Example 2: Create SAP Integration App
```bash
./generate_pattern.sh \
  --pattern mq_to_http \
  --app-name SAPIntegrationApp \
  --mq-queue SAP.REQUEST.QUEUE \
  --http-url https://sap-server.com/api/orders \
  --http-method POST
```

### Example 3: Create REST API App
```bash
./generate_pattern.sh \
  --pattern rest_to_database \
  --app-name CustomerAPIApp \
  --rest-path /api/customers \
  --db-schema CUSTOMERS \
  --db-table CUSTOMER_DATA
```

## Customization

After generation, you can customize:

1. **ESQL Logic**: Edit files in `esql/` directory
2. **Flow Structure**: Open `.msgflow` files in ACE Toolkit
3. **Subflows**: Modify reusable subflows in `subflows/` directory
4. **Properties**: Update connection properties in flow

## Best Practices

1. **Always use Error Handler subflow** for all flows
2. **Enable monitoring** for production flows
3. **Use correlation IDs** for request tracking
4. **Implement retry logic** for external calls
5. **Log to ETS queue** for error analysis
6. **Use connection pooling** for database operations
7. **Set appropriate timeouts** for HTTP requests
8. **Validate input data** before processing

## Troubleshooting

### Pattern Generation Fails
- Check Python version: `python3 --version`
- Verify pattern exists: `ls patterns/`
- Check permissions: `chmod +x scripts/*.sh`

### Import Fails in Toolkit
- Verify ACE Toolkit version
- Check workspace permissions
- Ensure no duplicate project names

### Deployment Fails
- Verify integration server is running: `mqsilist`
- Check BAR file: `mqsireadbar -b MyApp.bar`
- Review integration node logs

## Support

For issues and questions:
1. Check [`docs/PATTERNS_GUIDE.md`](docs/PATTERNS_GUIDE.md)
2. Review [`docs/DEPLOYMENT_GUIDE.md`](docs/DEPLOYMENT_GUIDE.md)
3. See [`docs/RUNTIME_COMMANDS.md`](docs/RUNTIME_COMMANDS.md)

## License

IBM Hackathon 2026 - Internal Use

## Version

1.0.0 - Initial Release